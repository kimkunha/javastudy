package kr.co.sist.multichat.server.run;

import kr.co.sist.multichat.server.view.ServerView;

public class ServerRun {

	public static void main(String[] args) {
		new ServerView();
	}
}
