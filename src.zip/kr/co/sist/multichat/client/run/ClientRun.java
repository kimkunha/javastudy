package kr.co.sist.multichat.client.run;

import kr.co.sist.multichat.client.view.ClientSelectTeamView;

public class ClientRun {

	public static void main(String[] args) {
		new ClientSelectTeamView();
	}
}
