package kr.co.sist.multichat.client.evt;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;

public class ClientSelectUserEvt extends WindowAdapter implements ItemListener {

	@Override
	public void itemStateChanged(ItemEvent e) {
		
	}
	
}
