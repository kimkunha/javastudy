package kr.co.sist.chat.server.run;

import kr.co.sist.chat.server.view.MultiChatServerView;

public class MultiChatServerRun {

	public static void main(String[] args) {
		new MultiChatServerView();
	}//class

}//main
